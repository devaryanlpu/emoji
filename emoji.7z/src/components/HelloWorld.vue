<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <div style="max-width: 280px; margin: auto; position: relative;">
      <textarea name="" id="" cols="30" rows="10" ref="textarea" v-model="input" @blur="showMessage"></textarea>
      <span style="position: absolute; right: 10px; bottom: 5px;z-index: 1; opacity: 0.5; cursor: pointer;" @click="toggleShow">&#128512;</span>
   <div v-if="show" style="max-width: 280px; margin: auto;font-size:30px">
      <span style="cursor: pointer; margin: 5px;" v-for="emo in emoji" :key="emo" v-html="emo" @click="addEmo"></span>
    </div>
    </div>
      
    
  </div>
</template>

<script>
import Emojis from '../emoji.js';
export default {
  name: 'HelloWorld',
  data() {
    return {
      show: false,
      emoji: Emojis,
      input: ''
    }
  },
  props: {
    msg: String
  },
  methods: {
    addEmo(e) {
      let pos = this.$refs.textarea.selectionStart
      let prev = this.input
                    .split('')
                    .slice(0, pos)
                    .join('')
      let latter = this.input
                    .split('')
                    .slice(pos)
                    .join('')
      this.input = prev + e.target.innerHTML + latter
      this.$refs.textarea.selectionEnd = pos
    },
    showMessage(){
console.log(this.input)
    },
     toggleShow() {
       this.show=!this.show
     } 
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
